
  # BVG Machine Homepage Design

  This is a code bundle for BVG Machine Homepage Design. The original project is available at https://www.figma.com/design/apwtskMTPyU4PRGoySTj6W/BVG-Machine-Homepage-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  